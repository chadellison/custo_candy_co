**To rebuild an environment**

The following command terminates and recreates the resources in an environment named ``my-env``::

  aws elasticbeanstalk rebuild-environment --environment-name my-env
